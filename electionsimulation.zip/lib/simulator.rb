require './methods.rb'

Simulation.new